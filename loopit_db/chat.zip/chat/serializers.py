from rest_framework import serializers
from .models import Product, Conversation, Message, Offer, Order
from django.contrib.auth.models import User
from django.db.models import Q  # Make sure this is at the top


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email']

class ProductSerializer(serializers.ModelSerializer):
    seller = UserSerializer(read_only=True)
    
    class Meta:
        model = Product
        fields = ['id', 'name', 'brand', 'price', 'description', 'seller', 'image', 'created_at']

class MessageSerializer(serializers.ModelSerializer):
    sender = UserSerializer(read_only=True)
    
    class Meta:
        model = Message
        fields = ['id', 'conversation', 'sender', 'text', 'created_at']

class OfferSerializer(serializers.ModelSerializer):
    class Meta:
        model = Offer
        fields = ['id', 'conversation', 'message', 'product', 'buyer', 'amount', 'status', 'created_at']

    def create(self, validated_data):
        # dummy hardcoded user jika tidak pakai auth
        buyer = User.objects.first()  # atau berdasarkan `validated_data['buyer_id']` kalau kamu kirim dari frontend
        validated_data['buyer'] = buyer
        return super().create(validated_data)

    def to_representation(self, instance):
        rep = super().to_representation(instance)
        rep['buyer'] = {
            "id": instance.buyer.id,
            "username": instance.buyer.username,
            "email": instance.buyer.email
        } if instance.buyer else None
        rep['product'] = {
            "id": instance.product.id,
            "name": instance.product.name,
            "brand": instance.product.brand,
            "price": str(instance.product.price),
            "seller": {
                "id": instance.product.seller.id,
                "username": instance.product.seller.username,
                "email": instance.product.seller.email
            } if instance.product.seller else None
        } if instance.product else None
        return rep

    

class MessageDetailSerializer(serializers.ModelSerializer):
    sender = UserSerializer(read_only=True)
    offer = OfferSerializer(read_only=True)
    
    class Meta:
        model = Message
        fields = ['id', 'conversation', 'sender', 'text', 'created_at', 'offer']

class ConversationSerializer(serializers.ModelSerializer):
    participants = UserSerializer(many=True, read_only=True)
    last_message = serializers.SerializerMethodField()
    unread_count = serializers.SerializerMethodField()  # Add this
    
    class Meta:
        model = Conversation
        fields = ['id', 'participants', 'created_at', 'updated_at', 'last_message', 'unread_count']
        
    def get_last_message(self, obj):
        last_msg = obj.messages.order_by('-created_at').first()
        if last_msg:
            return MessageSerializer(last_msg).data
        return None
        
    def get_unread_count(self, obj):
        user = self.context['request'].user
        return obj.messages.filter(read=False).exclude(sender=user).count()



class ConversationDetailSerializer(serializers.ModelSerializer):
    participants = UserSerializer(many=True, read_only=True)
    messages = MessageDetailSerializer(many=True, read_only=True)
    
    class Meta:
        model = Conversation
        fields = ['id', 'participants', 'messages', 'created_at', 'updated_at']

class OrderSerializer(serializers.ModelSerializer):
    buyer = UserSerializer(read_only=True)
    seller = UserSerializer(read_only=True)
    product = ProductSerializer(read_only=True)
    
    class Meta:
        model = Order
        fields = ['id', 'offer', 'buyer', 'seller', 'product', 'amount', 'status', 'created_at', 'updated_at']